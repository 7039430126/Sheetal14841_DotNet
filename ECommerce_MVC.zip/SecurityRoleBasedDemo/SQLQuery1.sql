﻿select * from Images;
delete from images where ImageId =12;
use OrganicFarmDB;


insert into Images values('Mango2','jpg', (select ImageUrl from OPENROWSET(BULK N'C:\Users\Shital\source\repos\OrganicFarmClient\OrganicFarmClient\wwwroot\lib\Images\Mango_2.jpg',SINGLE_BLOB) as ImageSource(ImageUrl)))
 





insert into Images values('C:\Users\Shital\source\repos\OrganicFarmClient\OrganicFarmClient\wwwroot\lib\Images\Apple.jpg')
insert into Product values(1,'Apple','FreshApple',250,2,1,12)