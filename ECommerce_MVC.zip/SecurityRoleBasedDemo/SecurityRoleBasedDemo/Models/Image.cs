﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SecurityRoleBasedDemo.Models
{
    public partial class Image
    {
        public Image()
        {
            Orders = new HashSet<Order>();
            Products = new HashSet<Product>();
        }

        public int ImageId { get; set; }
        public string ImageName { get; set; }
        public string ImageFormat { get; set; }
        public byte[] ImageUrl { get; set; }
        public string ProductImage { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
