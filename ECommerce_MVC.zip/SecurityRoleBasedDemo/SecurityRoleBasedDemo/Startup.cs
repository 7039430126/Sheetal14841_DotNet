using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SecurityRoleBasedDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SecurityRoleBasedDemo;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;


namespace SecurityRoleBasedDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();

            //Adding Services for Identity Database
            services.AddDbContext<MyIdentityDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            //CORS(Cross Origin Resource):Sending Request from Different Domain to Different Domain
            services.AddCors();

            //Adding Services for OrganicFarm Database
            services.AddDbContext<OrganicFarmDBContext>(options => options.UseSqlServer(Configuration.GetConnectionString("OrganicDB")));

            //Adding services for Storing Session
            services.AddDistributedMemoryCache();
            services.AddHttpContextAccessor();
            services.AddSession(Options=> {
                Options.IdleTimeout = TimeSpan.FromSeconds(5000);
                Options.Cookie.HttpOnly = true;
                Options.Cookie.IsEssential = true;
            });


            //add identity service with default password setting
            //minimum 6 char, uppercase,digit
            //services.AddIdentity<MyIdentityUser, MyIdentityRole>
            //    ().AddEntityFrameworkStores<MyIdentityDbContext>().AddDefaultTokenProviders();

            services.AddIdentity<MyIdentityUser, MyIdentityRole>(options =>
             {
                 //password settings
                 options.SignIn.RequireConfirmedEmail = false;
                 options.User.RequireUniqueEmail = false;
                 options.Password.RequireDigit = true;
                 options.Password.RequiredLength = 3;
                 options.Password.RequiredUniqueChars = 0;
                 options.Password.RequireLowercase = true;
                 options.Password.RequireNonAlphanumeric = false;
                 options.Password.RequireUppercase = false;

                //lock settings
                options.Lockout.MaxFailedAccessAttempts = 3;
                 options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(1); //default 5 min

                // user settings
                options.User.RequireUniqueEmail = false;
             }).AddEntityFrameworkStores<MyIdentityDbContext>().AddDefaultTokenProviders();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();

            app.UseStaticFiles(); //Middleware for Static Files stored in wwwroot folder

            app.UseRouting();

            app.UseCors(x => x.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()); // Middleware for CORS

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseSession();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Default}/{id?}");
            });
        }
    }
}
