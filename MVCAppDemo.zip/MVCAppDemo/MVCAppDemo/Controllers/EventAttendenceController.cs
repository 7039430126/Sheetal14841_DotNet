﻿using Microsoft.AspNetCore.Mvc;
using MVCAppDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static MVCAppDemo.Models.Attendies;

namespace MVCAppDemo.Controllers
{
    public class EventAttendenceController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult EventHome()
        {
            
            return View();
        }

        public IActionResult RegisterForm(string name,string email,bool willAttend)
        {
            Attendies a = new Attendies();
            return View();
            
        }

        public IActionResult WillAttend()
        {
           
            return View();
        }

        public IActionResult NotAttend()
        {
            return View();
        }


        public IActionResult ValidationOnComingOrNot()
        {
            Attendies a = new Attendies();
            ViewBag.name = a.Name;

            if(a.willAttend==true)
            {
                ViewBag.attend = "We are happy to see you there...!!!";
            }
            else
            {
                ViewBag.attend = "Sorry to hear that you will be a part of wonderful event :)";
            }
            return View();

        }
    }
}
