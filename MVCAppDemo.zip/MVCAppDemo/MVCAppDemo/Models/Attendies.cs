﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVCAppDemo.Models
{
    public class Attendies 
    {
        

        [Required(ErrorMessage = "Name is Compulsory Field")]
        [StringLength(10, ErrorMessage = "Maximum Name length is 10 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is Compulsory Field")]
        public string Email { get; set; }

        [Required(ErrorMessage = "This is Compulsory Field")]
        public bool willAttend { get; set; }


    }
}
