﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAppDemo.Models
{
    public class Employee
    {
        [Required(ErrorMessage ="Empid is compulsory field")]
        [RegularExpression(@"[0-9]{4}",ErrorMessage ="Enter four digit EmpId")]
        public int? EmpId { get; set; }

        [Required(ErrorMessage ="Emp Name is Compulsory Field")]
        [StringLength(10,ErrorMessage ="Maximum EmpName length is 10 characters")]
        public string EmpName { get; set; }

        [Required(ErrorMessage ="Salary is compulsory field")]
        public double? Salary { get; set; }
    }
}
